let trenutno = new Date();

let m = trenutno.getMonth();
let d = trenutno.getDate();
let g = trenutno.getFullYear();


